last <-
function(x) return(tail(x, n=1))
